;(self.webpackChunkdemo = self.webpackChunkdemo || []).push([
  [753],
  {
    5753: (e, t, n) => {
      'use strict'
      n.r(t), n.d(t, { default: () => a })
      n(8582)
      var l = n(8222),
        r = n(7294),
        u = n(5513)
      const a = function (e) {
        return r.createElement(
          r.Fragment,
          null,
          'Home',
          r.createElement('br', null),
          r.createElement(l.Z, null, r.createElement(u.rU, { to: '/about' }, 'About '))
        )
      }
    }
  }
])
